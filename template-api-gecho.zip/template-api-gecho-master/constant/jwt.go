package constant

const (
	JWTKey = "JWT_KEY"
)
