package constant

const (
	Authorization = "Authorization"
	Bearer        = "Bearer"
)
