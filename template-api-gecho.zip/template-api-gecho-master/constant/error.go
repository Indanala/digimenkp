package constant

const (
	Unauthorized  = "Unauthorized"
	ContextLogger = "Could not get context info for logger!"
)
