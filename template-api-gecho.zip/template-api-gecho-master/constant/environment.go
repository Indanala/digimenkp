package constant

const (
	Environment = "ENVIRONMENT"
	Development = "development"
	Testing     = "testing"
	Production  = "production"
)
