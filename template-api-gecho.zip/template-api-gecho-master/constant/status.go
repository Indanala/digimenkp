package constant

const (
	StatusSuccess = "Success"
	StatusError   = "Error"
)
