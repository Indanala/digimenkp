package constant

const (
	DBHost     = "DB_HOST"
	DBName     = "DB_NAME"
	DBUser     = "DB_USER"
	DBPassword = "DB_PASSWORD"
	DBSchema   = "DB_SCHEMA"
)
