package constant

const (
	HelloWorld = "Hello World!"
)
