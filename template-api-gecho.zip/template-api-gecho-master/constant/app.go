package constant

const (
	APPHost = "APP_HOST"
	APPPort = "APP_PORT"
)
