# template-api-gecho
This repository contains template project for API using Golang and Echo Framework

## Important
We need to refactor this project immediately, because using the current architecture will result in unexpected behavior, look at main.go for more details

## Todo
- [ ] Refactor Architecture
