package entity

type ExampleEntity struct {
	Title       string `json:"title"`
	Description string `json:"description"`
}
